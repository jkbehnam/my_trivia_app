package com.trivia.trivia.helper;

import junit.framework.TestCase;

import org.junit.Test;

import static org.junit.Assert.*;

public class HashedPasswordTest extends TestCase {

    @Test
    public void create() {

    }

    @Test
    public void toString() {
    }
}