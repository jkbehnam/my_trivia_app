package com.trivia.trivia.util;

/**
 * Created by cstudioo on 11/01/17.
 */

public class Constant {


    public static final String WS_URL = "https://cstudioo.000webhostapp.com/cstudio/";



    // Data passing variables

    public static final String PASS_TO_HOME_MSG = "home_msg";
}
