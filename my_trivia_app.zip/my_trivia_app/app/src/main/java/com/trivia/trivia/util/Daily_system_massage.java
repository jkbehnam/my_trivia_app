package com.trivia.trivia.util;

/**
 * Created by behnam_b on 8/29/2016.
 */
public class Daily_system_massage {
    private String answer;
    private String question;
    private int code;
    private int day;


    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }
}
