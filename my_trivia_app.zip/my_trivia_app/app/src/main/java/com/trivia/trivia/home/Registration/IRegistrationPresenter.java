package com.trivia.trivia.home.Registration;

public interface IRegistrationPresenter {
    void sendPhoneNumber();
    void sendCode();
    void sendUserdata();
}
