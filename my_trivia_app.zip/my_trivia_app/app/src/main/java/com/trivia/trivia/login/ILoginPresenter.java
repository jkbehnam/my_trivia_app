package com.trivia.trivia.login;

/**
 * Created by cstudioo on 05/01/17.
 */

public interface ILoginPresenter {

    void callLogin(String userName, String passWord);
}
