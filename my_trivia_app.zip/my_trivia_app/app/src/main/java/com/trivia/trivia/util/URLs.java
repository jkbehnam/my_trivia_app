package com.trivia.trivia.util;

public class URLs {
  static   String site="http://topia.arith.land/webservice/new_app";
    public static final String URL_REQUEST_SMS = "http://topia.arith.land/webservice/new_app/request_sms.php";
    public static final String URL_VERIFY_OTP = "http://topia.arith.land/webservice/new_app/verify_otp.php";
    public static final String URL_REG_GAMER = site+"/include/reg_gamer.php";
    public static final String URL_GET_QUESTIONS_LIST = site+"/include/get_question_list.php";
    public static final String URL_LOGIN = "http://topia.arith.land/webservice/new_app/include/Login_gamer.php";
    public static final String URL_EVENT_LIST =site+ "/include/get_event_list.php";
    public static final String URL_EVENT_LIST_REG =site+ "/include/get_event_list_reg.php";
    public static final String URL_GAMER_EVENT_REG = site+"/include/reg_gamer_event.php";
    public static final String URL_CHECK_USERNAME = site+"/include/username_check.php";
    public static final String URL_GET_MULTIPLECHOICE= site+"/include/get_multiple_question.php";

}
