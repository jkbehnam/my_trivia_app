package com.trivia.trivia.home.gameActivity;

public interface IGameMultipleChoice extends IGames {

}
